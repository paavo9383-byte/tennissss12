import math
from typing import Optional, Tuple

def implied_from_decimal_odds(odds: Optional[float]) -> Optional[float]:
    if odds is None or odds <= 1.0:
        return None
    return 1.0 / odds

def normalize_two_probs(p1: Optional[float], p2: Optional[float]) -> Tuple[float, float]:
    p1 = p1 or 0.0
    p2 = p2 or 0.0
    s = p1 + p2
    if s <= 0:
        return 0.5, 0.5
    return p1 / s, p2 / s

def expected_value(prob: float, odds: Optional[float]) -> float:
    if odds is None or odds <= 1.0:
        return 0.0
    # EV per 1€
    return prob * (odds - 1.0) - (1.0 - prob)

def kelly_fraction(prob: float, odds: Optional[float], fraction: float = 1.0) -> float:
    if odds is None or odds <= 1.0 or prob <= 0.0 or prob >= 1.0:
        return 0.0
    b = odds - 1.0
    q = 1.0 - prob
    f = (b * prob - q) / b
    return max(0.0, f) * max(0.0, min(1.0, fraction))
