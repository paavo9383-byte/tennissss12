import httpx
from typing import Optional, Dict, Any
import streamlit as st

BASE_URL = "https://api-football-v1.p.rapidapi.com/v3"

def _headers():
    return {
        "X-RapidAPI-Key": st.secrets["RAPIDAPI_KEY"],
        "X-RapidAPI-Host": st.secrets.get("RAPIDAPI_HOST","api-football-v1.p.rapidapi.com"),
    }

@st.cache_data(ttl=120)
def api_get(path: str, params: Optional[dict]=None) -> Dict[str, Any]:
    url = f"{BASE_URL}{path}"
    with httpx.Client(timeout=20) as client:
        r = client.get(url, params=params, headers=_headers())
        r.raise_for_status()
        return r.json()

def leagues(country: Optional[str] = None):
    params = {}
    if country:
        params["country"] = country
    return api_get("/leagues", params=params)

def fixtures(date: Optional[str] = None, league: Optional[int] = None,
            season: Optional[int] = None, live: Optional[bool] = None,
            fixture_id: Optional[int] = None, team: Optional[int] = None,
            last: Optional[int] = None):
    params = {}
    if fixture_id:
        params["id"] = fixture_id
    if date:
        params["date"] = date
    if league:
        params["league"] = league
    if season:
        params["season"] = season
    if live:
        params["live"] = "all"
    if team:
        params["team"] = team
    if last:
        params["last"] = last
    return api_get("/fixtures", params=params)

def odds(fixture_id: int):
    params = {"fixture": fixture_id}
    return api_get("/odds", params=params)

def fixtures_team_last(team_id: int, season: int, last: int = 5, league: Optional[int] = None):
    params = {"team": team_id, "season": season, "last": last}
    if league:
        params["league"] = league
    return api_get("/fixtures", params=params)
